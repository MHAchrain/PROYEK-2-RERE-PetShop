<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up(): void
{
    Schema::create('kategori', function (Blueprint $table) {
        $table->increments('id_kategori');
        $table->string('nama_kategori', 80);
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('kategori');
}
};
