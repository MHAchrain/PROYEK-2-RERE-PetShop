<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildSchema()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\PROYEK-2-RERE-PetShop\backend-laravel\vendor\filament\schemas\resources\views/components/grid.blade.php ENDPATH**/ ?>