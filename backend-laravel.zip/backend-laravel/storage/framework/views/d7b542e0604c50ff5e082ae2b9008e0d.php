<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\PROYEK-2-RERE-PetShop\backend-laravel\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>